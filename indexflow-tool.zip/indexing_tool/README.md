# IndexFlow — Google Indexing Tool

## Files:
- `backend/app.py` — Flask API server
- `backend/credentials.json` — Your Google service account key
- `backend/requirements.txt` — Python dependencies
- `frontend/index.html` — Beautiful UI

## Deploy on Railway (Free):

1. Go to railway.app → Login with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Upload these backend files
4. Add environment is automatic
5. Railway gives you a URL like: https://indexflow-xxx.railway.app

## After Deploy:

1. Open frontend/index.html
2. Change this line:
   `const API_BASE = 'http://localhost:5000/api';`
   To:
   `const API_BASE = 'https://your-railway-url.railway.app/api';`
3. Done!

## Local Testing:

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Then open frontend/index.html in browser.
